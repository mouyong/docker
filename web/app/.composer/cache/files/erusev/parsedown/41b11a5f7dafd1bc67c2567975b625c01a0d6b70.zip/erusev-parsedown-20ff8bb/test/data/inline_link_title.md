[single quotes](http://example.com 'Title')

[double quotes](http://example.com "Title")

[single quotes blank](http://example.com '')

[double quotes blank](http://example.com "")

[space](http://example.com "2 Words")

[parentheses](http://example.com/url-(parentheses) "Title")