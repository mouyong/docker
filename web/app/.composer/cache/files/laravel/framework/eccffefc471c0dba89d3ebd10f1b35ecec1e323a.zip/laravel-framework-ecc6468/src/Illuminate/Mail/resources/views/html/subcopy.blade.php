<table class="subcopy" width="100%" cellpadding="0" cellspacing="0">
    <tr>
        <td>
            {{ Illuminate\Mail\Markdown::parse($slot) }}
        </td>
    </tr>
</table>
