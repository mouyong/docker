<?php

namespace Fixtures\Prophecy;

class EmptyClass
{
}
