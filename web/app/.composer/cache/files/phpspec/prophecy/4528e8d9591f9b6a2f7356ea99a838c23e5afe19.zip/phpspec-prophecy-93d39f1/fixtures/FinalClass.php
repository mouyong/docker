<?php

namespace Fixtures\Prophecy;

final class FinalClass
{
}
