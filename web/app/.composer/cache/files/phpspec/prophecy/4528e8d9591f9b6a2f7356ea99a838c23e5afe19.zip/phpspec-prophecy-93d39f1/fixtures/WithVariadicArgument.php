<?php

namespace Fixtures\Prophecy;

class WithVariadicArgument
{
    function methodWithArgs(...$args)
    {
    }
}
